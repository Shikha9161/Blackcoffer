package com.example.netclanexplorer.ui.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.example.netclanexplorer.data.model.Details
import mktechit28.blogspot.com.netclanexplorerShikha.R
import mktechit28.blogspot.com.netclanexplorerShikha.databinding.LayoutDesignBinding

class persondataAdapter(
    var context: Context,
    var dataList: ArrayList<Details>
) : RecyclerView.Adapter<persondataAdapter.ViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(
            DataBindingUtil.inflate(
                LayoutInflater.from(parent.context),
                R.layout.layout_design,
                parent,
                false
            )
        )
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        var list : Details = dataList[position]
        holder.binding.PersonName.text=list.name
        holder.binding.Personlocation.text=list.location
        holder.binding.data.text=list.data
        holder.binding.quotetion.text=list.quotes
     }

    override fun getItemCount(): Int {
        return dataList.size
     }
    class ViewHolder (var binding: LayoutDesignBinding) : RecyclerView.ViewHolder(binding.root) {

    }

}