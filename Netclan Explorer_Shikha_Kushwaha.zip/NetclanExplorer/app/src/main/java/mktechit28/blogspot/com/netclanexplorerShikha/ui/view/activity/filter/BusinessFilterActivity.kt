package mktechit28.blogspot.com.netclanexplorerShikha.ui.view.activity.filter

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import mktechit28.blogspot.com.netclanexplorerShikha.databinding.ActivityBusinessFilterBinding

class BusinessFilterActivity : AppCompatActivity() {
    lateinit var bin: ActivityBusinessFilterBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        bin = ActivityBusinessFilterBinding.inflate(layoutInflater)
        setContentView(bin.root)
    }
}