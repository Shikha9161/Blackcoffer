package mktechit28.blogspot.com.netclanexplorerShikha.utils;

import android.net.Uri;
import android.widget.ArrayAdapter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class MCons {
    public static final  ArrayList<Uri> mArrayUri = new ArrayList<Uri>();
    public static final   List<byte[]> resum_list = new ArrayList<>();
    public static final boolean IS_TEST_MODE = false;
    public static boolean IS_PENDING_REJECTED = false;
    public static final boolean IS_PENDING = false;
    public static boolean IS_VIEW_MODE = false;
    public static boolean IS_DROPDOWN_REJECTED = false;
    public static int IS_EDIT_MODE = 0;
    public static Uri first_pic = null;
    public static byte[] byteArray = null;
    public static final int CAMERA_REQ_CODE = 1;
    public static final int GALLERY_REQ_CODE = 2;
    public static final int MULTI_STORE_AD_PROOF_REQ_CODE = 10;
    public static final int MULTI_CHECKLIST_REQ_CODE = 11;
    public static final int MULTI_CANCEL_CHEQUE_REQ_CODE = 12;
    public static boolean IS_POST_TIME = false;
    public static String INTRO_PASS = "false";
    public static int PHOTOS_COUNT = 0;
    /*public static int MY_CAMERA_PERMISSION_CODE = 1;*/
    public static final String POST = "post";
    public static final String RESPONSE = "response";
    public static final String LAST_ACTIVE_COUNT = "LAST_ACTIVE_COUNT";

    /***Client based fields value*/
    public static String SELECT_DCNAME = "Select Dc Name";
    public static String SELECT_DCCode = "Select Dc Station Code";
    public static String ENTER_STOREFULL_ADDRESS = "Enter Store Full Address";
    public static String available = "";
    public static String statetext = "";
    public static String purpose = "";
    public static String business = "";


    public static final String GSP_DROPDOWN = "GSP_DROPDOWN";
    public static final String VSP_DROPDOWN = "VSP_DROPDOWN";
    public static final String DP_DROPDOWN = "DP_DROPDOWN";
    public static final String BA_DROPDOWN = "BA_DROPDOWN";
    public static final String XB_HRMS_DROPDOWN = "XB_HRMS_DROPDOWN";

    public static final String GSP_STORE_ADDRESS_SIZE = "GSP_STORE_ADDRESS_SIZE";
    public static final String GSP_CANCELLED_CHEQUE_SIZE = "GSP_CANCELLED_CHEQUE_SIZE";
    public static final String GSP_STORE_VAL_ = "GSP_VAL_";
    public static final String GSP_CANCELLED_CHEQUE_VAL_ = "GSP_CANCELLED_CHEQUE_VAL_ ";

    public static final String VSP_STORE_ADDRESS_SIZE = "VSP_STORE_ADDRESS_SIZE";
    public static final String VSP_STORE_VAL_ = "VSP_STORE_VAL_";
    public static final String VSP_CANCELLED_CHEQUE_SIZE = "VSP_CANCELLED_CHEQUE_SIZE";
    public static final String VSP_CANCELLED_CHEQUE_VAL_ = "VSP_CANCELLED_CHEQUE_VAL_ ";
    public static final String VSP_CHECKLIST_FORM_SIZE = "VSP_CHECKLIST_FORM_SIZE";
    public static final String VSP_CHECKLIST_VAL_ = "VSP_CHECKLIST_VAL_ ";
    public static final String VSP_RC_VAL_ = "VSP_RC_VAL_";
    public static final String VSP_RC_SIZE = "VSP_RC_SIZE";

    public static final String DP_STORE_VAL_ = "DP_STORE_VAL_";
    public static final String DP_STORE_ADDRESS_SIZE = "DP_STORE_ADDRESS_SIZE";
    public static final String DP_CANCELLED_CHEQUE_VAL_ = "DP_CANCELLED_CHEQUE_VAL_ ";
    public static final String DP_CANCELLED_CHEQUE_SIZE = "DP_CANCELLED_CHEQUE_SIZE";
    public static final String DP_CHECKLIST_VAL_ = "DP_CHECKLIST_VAL_ ";
    public static final String DP_CHECKLIST_FORM_SIZE = "DP_CHECKLIST_FORM_SIZE";

    public static final String PICSIZE_STORE = "PICSIZE_STORE";
    public static final String PICSIZE_CANCEL = "PICSIZE_CANCEL";
    public static final String PICSIZE_CHECKLIST = "PICSIZE_CHECKLIST";

    public static boolean IS_CLIENT_XPRESSBEES = false;
    public static boolean IS_CLIENT_GROFERS = false;
    public static boolean IS_CLIENT_CARGO = false;
    public static boolean IS_CLIENT_MILLION_MIND = false;
    public static boolean IS_CLIENT_XB_STAFF= false;
    public static boolean SHARE_BUTTON = false;
    public static boolean checkVisibility = false;

    public static final String CLIENT_ID_GROFERS = "1";
    public static final String CLIENT_ID_XB = "3";
    public static final String CLIENT_ID_CARGO = "4";
    public static final String CLIENT_ID_PIDLEE = "5"; //CLIENT_ID='5', CLIENT_NAME='Pidlee'
    public static final String CLIENT_ID_MILLION_MIND = "5";
    public static final String CLIENT_ID_XB_STAFF = "7";

    public static final String XpressBees = "Xpressbees";
    public static final String Grofers = "Grofers";
    public static final String Cargo = "Xpressbees Cargo"; /*cargo xb client*/
    public static final String XpressbeesPartner = "XpressbeesPartner";
    public static final String XbStaffOnBoarding = "XbStaffOnBoarding";
    public static final String SHOWCASE_ID_1 = "sequence example";
    public static final String SHOWCASE_ID_2 = "sequence exampl";
    public static final String SHOWCASE_ID_3 = "sequence exampls";

    /*login credentails*/
    public static final String SRE_EMAIL = "email";
    public static final String SRE_NAME = "SRE_NAME";
    public static final String SRE_MOB = "SRE_MOB";
    public static final String SRE_EMP_ID = "SRE_EMP_ID";
    public static final String SRE_DESIGNATION = "SRE_DESIGNATION";
    public static final String SRE_MGR_TYPE = "SRE_MGR_TYPE";

    public static final String USERNAME = "name";
    public static final String USERPASSWORD = "password";
    public static final String APPVERSION = "version";
    public static final String LOGIN_FLAG = "";
    public static final String AGREEMENT_STATUS = "not";
    public static  String USERID = "0";
    public static  String DESIGNATION = null;
    public static  String BANKNAME = null;
    public static final String TYPE = "type";
    public static String CLIENT_ID = "clientId";
    public static String INDEX_ID = "";
    public static int INDEX_ID_GROFERS = 0;
    public static final String CLIENT_NAME = "clientNAme";

    /*Singup constants*/
    public static String SIGNUP_EMP_ID = "SIGNUP_EMP_ID";
    public static String SIGNUP_NAME = "SIGNUP_NAME";
    public static String SIGNUP_NUMBER = "SIGNUP_NUMBER";
    public static String SIGNUP_EMAIL = "SIGNUP_EMIAL";
    public static String SIGNUP_PASSWORD = "SIGNUP_PASSWORD";

    /*basic credentials*/
    public static final String username = "ISOURSE";
    public static final String password = "gariCR8gD+jhARov4uL2UIkn712JTrfSekjvzlYuDaU=";
    public static final int fade_in_out_duration = 90;
    public static String IsRatingDismissed = "false";
    public static String ActiveUser = "ActiveUser";
    public static String RejectedUser = "RejectedUser";
    public static String ApprovedUser = "ApprovedUser";
    public static String PendingUser = "PendingUser";
    public static String UserType = "Type";
    public static String UserId = "UserId";

    //    public static TextView ownerPic_button, GstNo_btn;
//    public static EditText owner_email, store_gstNo;
//    public static ImageView ownerPicImgview, GstNo_Imgview;
    /*Cargo constants*/
    public static final int BA_PAN_FRNT = 1;
    public static final int BA_ADHAAR_FRNT = 2;
    public static final int BA_ADHAAR_BCK = 3;
    public static final int BA_DL_FRNT = 4;
    public static final int BA_DL_BCK = 5;
    public static final int CARGO_GST_CERTIFICATE = 6;
    public static final int CARGO_BNK_DEPOSIT_RECIEPT = 7;
    public static final int REF_1_PAN_FRNT = 8;
    public static final int REF_1_AADHAAR_FRNT = 9;
    public static final int REF_1_AADHAAR_BCK = 10;
    public static final int REF_2_PAN_FRNT = 11;
    public static final int REF_2_AADHAAR_FRNT = 12;
    public static final int REF_2_AADHAAR_BCK = 13;
    public static final int BLNK_CHEQUE = 14;
    public static final int GRNT1_ADHAAR_FRNT = 15;
    public static final int GRNT1_ADHAAR_BCK = 16;
    public static final int GRNT2_ADHAAR_FRNT = 17;
    public static final int GRNT2_ADHAAR_BCK = 18;
    public static final int GRNT1_PAN_FRNT = 19;
    public static final int GRNT2_PAN_FRNT = 20;
    public static final int GRNT1_DEC_FRNT = 21;
    public static final int GRNT2_DEC_FRNT = 22;
    public static final int BA_DEC_FRNT = 23;
    public static final int BA_CHEQUE_DEC_FRNT = 24;


    //Todo New Cargo Changes Entity Type  By  Prakash Mehta as on 13/08/2021 CG13/08/2021

    public static final int Company_PAN_Card_Picture = 25;
    public static final int Company_TAN_Card_Picture = 26;
    public static final int Certificate_Incorporation_Picture = 27;
    public static final int Resolution_Letter_Entity_Authorising_Signatory_Picture = 28;
    public static final int Authorize_person_Photo = 29;

    public static final int Authorize_person_Aadhar_card_frnt = 30;
    public static final int Authorize_person_Aadhar_card_back = 31;
    public static final int Resolution_Letter_Authorising_Signatory_Picture = 32;
    public static final int Certificate_LLP_Registration_Picture = 33;
    public static final int Partnership_PAN_Card_Picture = 34;
    public static final int Partnership_TAN_Card_Picture = 35;
    public static final int Address_Proof_Place_business_Address_Proof = 36;
    public static final int List_of_Partners = 37;
    public static final int Partner_Aadhar_card_Picture_FRONT = 38;
    public static final int Partner_Aadhar_card_Picture_BACK = 39;
    public static final int Partner_Authorised_Signatory_PAN_Card_Picture = 40;
    public static final int Partner_Authorised_Signatory_Permanent_Address_Proof_Picture = 41;
    public static final int Proof_of_Business_Firm_Document_Picture = 42;
    public static final int Proprietor_PAN_Picture = 43;
    public static final int Proprietorship_TAN_Card_Picture = 44;
    public static final int Proprietor_Address_Proof_Picture = 45;
    public static final String BA_AADHAR_NO = "46";


    /*field would be created for single pictures not multi*/
    public static final int flag = 0;
    public static final int OWNER_ADHAR_CARD_FRONT = 1;
    public static final int OWNER_ADHAR_CARD_BACK = 2;
    public static final int REF_ADHAR_CARD_FRONT = 3;
    public static final int REF_ADHAR_CARD_BACK = 4;
    public static final int OWNER_PAN_CARD_FRONT = 5;
    public static final int REF_PAN_CARD_BACK = 6;
    public static final int REF_PAN_CARD_FRONT = 7;
    public static final int FE_ADHAR_CARD_FRONT = 8;
    public static final int FE_ADHAR_CARD_BACK = 9;
    public static final int GROFERS_ONBOARDING_FEE_SLIP = 10;
    public static final int VAN_OWNER_ADHAAR_FRONT = 11;
    public static final int VAN_OWNER_ADHAAR_BACK = 12;
    public static final int VAN_RC = 13;
    public static final int VAN_PC = 14;
    public static final int VEHICLE_INSURANCE = 15;
    public static final int VAN_PIC_NO_FRONT = 16;
    public static final int VAN_PIC_NO_BACK = 17;
    public static final int VAN_DRIVER_AADHAR_FRONT = 18;
    public static final int VAN_DRIVER_ADHAAR_BACK = 19;
    public static final int GROFERS_DEPOSIT_ONBOARDING_FEE_SLIP = 20;
    public static final int VAN_FITNESS = 21;
    public static final int NOC = 22;
    public static final int STORE_FRONT_PIC = 23;
    public static final int ROAD_CLEARANCE_TAX = 24;
    public static final int FRNT_DRIVING_DL = 25;
    public static final int BCK_DRIVING_DL = 26;
    public static final int ONBOARDING_DEPOSIT_FEE_SLIP = 27;
    public static final int GROFERS_ONBOARDING__DEPOSIT_FEE_SLIP = 28;
    public static final int DP_STORE_FRONT_PIC = 29;
    public static final int OWNER_PIC = 30;
    public static final int STORE_GSTIN = 31;
    public static final int BANK_DEPOSIT_RECIPT = 32;
    public static final int CANCEL_CHEQUE = 33;
    public static final int STORE_ADRESS_PIC = 34;
    public static final int VAN_CHECKLIST_FROM = 35;
    public static final int VAN_REG_CERIFICATE = 36;
    public static final int DP_ONBOARD_CHECKLIST = 37;
    public static final int DRIVER_LICENCE_PIC = 38;
    public static final int RESUME = 39;
    //3pl
    public static final int PL_Aadhar_front1 = 32;
    public static final int PL_Aadhar_Back = 33;
    public static final int PL_Pan_Card = 34;
    public static final int PL_Driving_Licence_Image = 35;

    //FLP

    public static final int FLP_Aadhar_front = 36;
    public static final int FLP_Aadhar_Back = 37;
    public static final int FLP_Pan_Card = 38;
    public static final int FLP_Cancel_Cheque = 39;
    //CPU
    public static final int CPU_Aadhar_front1 = 40;
    public static final int CPU_Cancel_Cheque = 41;
    public static final int CPU_Aadhar_Back = 42;
    public static final int CPU_Pan_Card = 43;
    public static final int CPU_Driving_Licence_Image = 44;

    //ASC
    public static final int ASC_Aadhar_front1 = 45;
    public static final int ASC_Cancel_Cheque = 46;
    public static final int ASC_Aadhar_Back = 47;
    public static final int ASC_Pan_Card = 48;

    public static byte[] store_address_proof_byte_array1;
    public static byte[] store_address_proof_byte_array2;
    public static byte[] store_address_proof_byte_array3;
    public static byte[] store_address_proof_byte_array4;

    public static byte[] checklist_form_byte_array1;
    public static byte[] checklist_form_byte_array2;
    public static byte[] checklist_form_byte_array3;
    public static byte[] checklist_form_byte_array4;

    public static byte[] cancelCheckPass_byte_array1;
    public static byte[] cancelCheckPass_byte_array2;
    public static byte[] cancelCheckPass_byte_array3;
    public static byte[] cancelCheckPass_byte_array4;

    /*Xpressbees fields*/
    public static byte[] van_rc_byte_array1;
    public static byte[] van_rc_byte_array2;
    public static byte[] van_rc_byte_array3;
    public static byte[] van_rc_byte_array4;

//    public static List<DropDownSingleObject> dropDownSingleObjects;
//    public static ResClient dropDownSingleObjectsList;
//    public static List<ResGetRateMatrix> matrixList;
    public static List<byte[]> storeList, cancelList, checkList, rcList;

    public static ArrayAdapter<String> availability_adapter;
    public static ArrayList<String> availability;

    public static ArrayAdapter<String> dcName_adapter;
    public static ArrayAdapter<String> stateAdapter;
    public static ArrayAdapter<String> emergency_adapter;
    public static ArrayAdapter<String> vendor_adapter;
    public static ArrayAdapter<String> bankName_adapter;
    public static ArrayAdapter<String> branchHub_adapter;
    public static ArrayAdapter<String> employeeCategory_adapter;
    public static ArrayAdapter<String> dc_code_station_code_adapter;
    public static ArrayAdapter<String> pinCode_adapter;
    public static ArrayAdapter<String> married_adapter;
    public static ArrayAdapter<String> gender_adapter;
    public static ArrayAdapter<String> businessSegmentAdapter;
    public static ArrayAdapter<String> designationAdapter;
    public static ArrayAdapter<String> departmentAdapter;
    public static ArrayAdapter<String> roleAdapter;
    public static ArrayAdapter<String> subLocationAdapter;
    public static ArrayAdapter<String> esNameAdapter;
    public static ArrayAdapter<String> esBcplNameAdapter;
    public static ArrayAdapter<String> businessverticalAdapter;
    public static ArrayAdapter<String> businessBcplverticalAdapter;

//    public static ArrayList<String> availability;
    public static ArrayList<String> dcName;
    public static ArrayList<String> city;
    public static ArrayList<String> maritalStatus;
    public static ArrayList<String> EntityType;
    public static ArrayList<String> esName;
    public static ArrayList<String> esBcplName;
    public static ArrayList<String> subLoaction;
    public static ArrayList<String> dc_code_station_code;
    public static ArrayList<String> designation;
    public static ArrayList<String> businessSegment;
    public static ArrayList<String> role;
    public static ArrayList<String> businessVertical;
    public static ArrayList<String> businessBcplVertical;
    public static ArrayList<String> pinCode;
    public static ArrayList<String> pcs;
    public static ArrayList<String> state;
    public static ArrayList<String> belongingState;
    public static ArrayList<String> bank_name;
    public static ArrayList<String> slots;
    public static ArrayList<String> vendorName;
    public static ArrayList<String> emergencyNo;
    public static ArrayList<String> genderStatus;
    public static ArrayList<String> branchHub;
    public static ArrayList<String> employeeCategory;
    public static ArrayList<String> clientName;
    public static ArrayList<String> departmentName;
    public static ArrayList<String> designationName;
    public static ArrayList<String> type_of_vehicle_registration;
    public static List<String> SRE_FROM_TYPE = new ArrayList<>();
    public static ArrayAdapter<String> clientName_adapter;


    public static enum FORMTYPE {
        GSP, GEP, VSP, DP, FLX, _3PL, FLP, CPU;
    }

    public static HashMap<String, Integer> storetypeMap;
    public static HashMap<String, Integer> businessBcplVerticalMap;
    public static HashMap<String, Integer> dcnameMap;
    public static HashMap<String, Integer> cityMap;
    public static HashMap<String, Integer> maritalstatusMap;
    public static HashMap<String, Integer> genderNameMap;
    public static HashMap<String, Integer> esMap;
    public static HashMap<String, Integer> esBcplNameMap;
    public static HashMap<String, Integer> dc_code_station_codeMap;
    public static HashMap<String, Integer> designationMap;
    public static HashMap<String, Integer> businessSegmentMap;
    public static HashMap<String, Integer> Entitymap;
    public static HashMap<String, Integer> roleMap;
    public static HashMap<String, Integer> sublocationMap;
    public static HashMap<String, Integer> pin_codeMap;
    public static HashMap<String, Integer> pcsMap;
    public static HashMap<String, Integer> type_of_vehicle_registrationMap;
    public static HashMap<String, Integer> stateMap;
    public static HashMap<String, Integer> belongingstateMap;
    public static HashMap<String, Integer> bank_nameMap;
    public static HashMap<String, Integer> vandor_nameMap;
    public static HashMap<String, Integer> timeSlotMap;
    public static HashMap<Integer, String> storetypeMapForGettingStoretypeName;
    public static HashMap<Integer, String> businessBcplVerticalMapForGettingbusinessBcplVertical;
    public static HashMap<String, Integer> vendorNameMap;
    public static HashMap<Integer, String> vendorNameMapForgettingStoreTypeName;
    public static HashMap<String, Integer> emergencyNoMap;
    public static HashMap<Integer, String> emergencyNoMapForGettingTypeName;
    public static HashMap<Integer, String> branchHubMap;
    public static HashMap<Integer, String> branchHubMapForGettingTypeName;
    public static HashMap<String, Integer> employeeCategoryMap;
    public static HashMap<String, Integer> clientNameMap;
    public static HashMap<String, Integer> departmentNameMap;
    public static HashMap<String, Integer> designationNameMap;
    public static HashMap<String, Integer> businessVerticalMap;
    public static HashMap<Integer, String> employeeCategoryMapForGettingName;
    public static HashMap<Integer, String> clientNameMapForGettingNameMap;
    public static HashMap<Integer, String> branchNameMapForGettingNameMap;
    public static HashMap<Integer, String> departmentNameMapForGettingNameMap;
    public static HashMap<Integer, String> designationNameMapForGettingNameMap;
    public static HashMap<Integer, String> businessVerticalMapForGettingNameMap;

    public static HashMap<Integer, String> dcnameMapForGettingdcname;
    public static HashMap<Integer, String> cityMapForGettingcityName;
    public static HashMap<Integer, String> maritalstatusMapForGettingName;
    public static HashMap<Integer, String> genderStatusMapForGettingName;
    public static HashMap<Integer, String> EntityTypeMapForGettingEntityType;
    public static HashMap<Integer, String> esMapForGettingEsName;
    public static HashMap<Integer, String> esBcplNameMapForGettingEsBcplName;
    public static HashMap<Integer, String> dc_code_station_codeMapForGettingdc_code_station_codeName;
    public static HashMap<Integer, String> designationMapForGettingdesignation;
    public static HashMap<Integer, String> businessSegmentMapForGettingbusinessSegment;
    public static HashMap<Integer, String> roleMapForGettingrole;
    public static HashMap<Integer, String> sublocationmapforgettingname;
    public static HashMap<Integer, String> pincode_MapForGetting_pincodeName;
    public static HashMap<String, String> pcs_MapForGetting_pcs;
    public static HashMap<Integer, String> type_of_vehicle_registrationMapForGetting_typeRegVehicle;
    public static HashMap<Integer, String> stateMapForGettingStateName;
    public static HashMap<Integer, String> Belonging_stateMapForGettingStateName;
    public static HashMap<Integer, String> bank_nameMapForGettingbank_name;
    public static HashMap<Integer, String> bank_nameMapForGettingclient_name;
    public static HashMap<Integer, String> timeSlotMapForGettingSlots;

}
