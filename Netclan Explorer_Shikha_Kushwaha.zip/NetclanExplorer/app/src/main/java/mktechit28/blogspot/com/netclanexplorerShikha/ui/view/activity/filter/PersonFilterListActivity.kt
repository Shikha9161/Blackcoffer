package mktechit28.blogspot.com.netclanexplorerShikha.ui.view.activity.filter

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.netclanexplorer.ui.view.activity.MainActivity
import mktechit28.blogspot.com.netclanexplorerShikha.databinding.ActivityPersonFilterListBinding

class PersonFilterListActivity : AppCompatActivity() {
    lateinit var bin: ActivityPersonFilterListBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        bin = ActivityPersonFilterListBinding.inflate(layoutInflater)
        btnListener()
        setContentView(bin.root)
    }

    private fun btnListener() {
        bin.dashboardFilter.crossBtn.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
        }
    }
}