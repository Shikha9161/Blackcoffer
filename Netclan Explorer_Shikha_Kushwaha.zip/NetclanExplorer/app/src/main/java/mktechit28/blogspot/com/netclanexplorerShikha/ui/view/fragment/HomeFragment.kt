package com.example.netclanexplorer.ui.view.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.SeekBar
import androidx.fragment.app.Fragment
import com.example.netclanexplorer.ui.view.activity.MainActivity
import mktechit28.blogspot.com.netclanexplorerShikha.R
import mktechit28.blogspot.com.netclanexplorerShikha.databinding.FragmentHomeBinding
import mktechit28.blogspot.com.netclanexplorerShikha.utils.MCons


class HomeFragment(allDataAccess: MainActivity) : Fragment() {
    private lateinit var availableText:String
    var isCoffee: Boolean? = false
    var isBusiness: Boolean? = false
    var isHobbies: Boolean? = false
    var isFrienship: Boolean? = false
    var isMovies: Boolean? = false
    var isDinning: Boolean? = false
    var isDating: Boolean? = false
    var isMatrimony: Boolean? = false
    var accessData = allDataAccess
    var minusKm: Int = 0
    var plussKm: Int = 0
    lateinit var binding: FragmentHomeBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding= FragmentHomeBinding.inflate(inflater,container,false)
        initViews()
        btnListener()
        setAdapter()
        return binding.root
     }

    private fun btnListener() {

    }

    private fun initViews(){
        binding.seekbar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                binding.plusKm.visibility = View.VISIBLE
                binding.seekbar.progress.toString()
            }
            override fun onStartTrackingTouch(seekBar: SeekBar) {
                if (seekBar != null){
                    minusKm = seekBar.progress
                }
            }
            override fun onStopTrackingTouch(seekBar: SeekBar) {
                plussKm = seekBar.progress
            }
        })
        binding.saveBtn.setOnClickListener {
            MCons.available = availableText
            MCons.statetext = binding.status.text.toString()
            MCons.purpose = binding.purposeId.coffee.text.toString()
            accessData.initViewPager()
//            val fragment: Fragment = ExploreFragment()
//            val fragmentManager: FragmentManager = requireActivity().supportFragmentManager
//            val fragmentTransaction: FragmentTransaction = fragmentManager.beginTransaction()
//            fragmentTransaction.replace(com.example.netclanexplorer.R.id.frame, fragment)
//            fragmentTransaction.addToBackStack(null)
//            fragmentTransaction.commit()
        }


        binding.purposeId.coffee.setOnClickListener(
            View.OnClickListener {
                if (isCoffee == true){
                    isCoffee = false
//                    bin.mainId.purposeId.coffee.setBackgroundColor(R.color.colorPrimary)
                    binding.purposeId.coffee.setBackgroundColor(resources.getColor(R.color.white))
                    binding.purposeId.coffee.setTextColor(resources.getColor(R.color.colorPrimary))
                }else {
                    isCoffee = true
                    isBusiness = false
                    isHobbies = false
                    isFrienship = false
                    isMovies = false
                    isDinning = false
                    isDating = false
                    isMatrimony = false
                    binding.purposeId.coffee.setBackgroundColor(resources.getColor(R.color.colorPrimary))
                    binding.purposeId.coffee.setTextColor(resources.getColor(R.color.white))

                }
            })
        binding.purposeId.business.setOnClickListener(
            View.OnClickListener {
                if (isBusiness == true){
                    isBusiness = false
//                    bin.mainId.purposeId.coffee.setBackgroundColor(R.color.colorPrimary)
                    binding.purposeId.business.setBackgroundColor(resources.getColor(R.color.white))
                    binding.purposeId.business.setTextColor(resources.getColor(R.color.colorPrimary))
                }else {
                    isCoffee = false
                    isBusiness = true
                    isHobbies = false
                    isFrienship = false
                    isMovies = false
                    isDinning = false
                    isDating = false
                    isMatrimony = false
                    binding.purposeId.business.setBackgroundColor(resources.getColor(R.color.colorPrimary))
                    binding.purposeId.business.setTextColor(resources.getColor(R.color.white))

                }
            })
        binding.purposeId.hobbies.setOnClickListener(
            View.OnClickListener {
                if (isHobbies == true){
                    isHobbies = false
//                    bin.mainId.purposeId.coffee.setBackgroundColor(R.color.colorPrimary)
                    binding.purposeId.hobbies.setBackgroundColor(resources.getColor(R.color.white))
                    binding.purposeId.hobbies.setTextColor(resources.getColor(R.color.colorPrimary))
                }else {
                    isCoffee = false
                    isBusiness = false
                    isHobbies = true
                    isFrienship = false
                    isMovies = false
                    isDinning = false
                    isDating = false
                    isMatrimony = false
                    binding.purposeId.hobbies.setBackgroundColor(resources.getColor(R.color.colorPrimary))
                    binding.purposeId.hobbies.setTextColor(resources.getColor(R.color.white))

                }
            })
        binding.purposeId.friendship.setOnClickListener(
            View.OnClickListener {
                if (isFrienship == true){
                    isFrienship = false
//                    bin.mainId.purposeId.coffee.setBackgroundColor(R.color.colorPrimary)
                    binding.purposeId.friendship.setBackgroundColor(resources.getColor(R.color.white))
                    binding.purposeId.friendship.setTextColor(resources.getColor(R.color.colorPrimary))
                }else {
                    isCoffee = false
                    isBusiness = false
                    isHobbies = false
                    isFrienship = true
                    isMovies = false
                    isDinning = false
                    isDating = false
                    isMatrimony = false
                    binding.purposeId.friendship.setBackgroundColor(resources.getColor(R.color.colorPrimary))
                    binding.purposeId.friendship.setTextColor(resources.getColor(R.color.white))

                }
            })
        binding.purposeId.movies.setOnClickListener(
            View.OnClickListener {
                if (isMovies == true){
                    isMovies = false
//                    bin.mainId.purposeId.coffee.setBackgroundColor(R.color.colorPrimary)
                    binding.purposeId.movies.setBackgroundColor(resources.getColor(R.color.white))
                    binding.purposeId.movies.setTextColor(resources.getColor(R.color.colorPrimary))
                }else {
                    isCoffee = false
                    isBusiness = false
                    isHobbies = false
                    isFrienship = false
                    isMovies = true
                    isDinning = false
                    isDating = false
                    isMatrimony = false
                    binding.purposeId.movies.setBackgroundColor(resources.getColor(R.color.colorPrimary))
                    binding.purposeId.movies.setTextColor(resources.getColor(R.color.white))

                }
            })
        binding.purposeId.dinning.setOnClickListener(
            View.OnClickListener {
                if (isDinning == true){
                    isDinning = false
//                    bin.mainId.purposeId.coffee.setBackgroundColor(R.color.colorPrimary)
                    binding.purposeId.dinning.setBackgroundColor(resources.getColor(R.color.white))
                    binding.purposeId.dinning.setTextColor(resources.getColor(R.color.colorPrimary))
                }else {
                    isCoffee = false
                    isBusiness = false
                    isHobbies = false
                    isFrienship = false
                    isMovies = false
                    isDinning = true
                    isDating = false
                    isMatrimony = false
                    binding.purposeId.dinning.setBackgroundColor(resources.getColor(R.color.colorPrimary))
                    binding.purposeId.dinning.setTextColor(resources.getColor(R.color.white))

                }
            })
        binding.purposeId.dating.setOnClickListener(
            View.OnClickListener {
                if (isDating == true){
                    isDating = false
//                    bin.mainId.purposeId.coffee.setBackgroundColor(R.color.colorPrimary)
                    binding.purposeId.dating.setBackgroundColor(resources.getColor(R.color.white))
                    binding.purposeId.dating.setTextColor(resources.getColor(R.color.colorPrimary))
                }else {
                    isCoffee = false
                    isBusiness = false
                    isHobbies = false
                    isFrienship = false
                    isMovies = false
                    isDinning = false
                    isDating = true
                    isMatrimony = false
                    binding.purposeId.dating.setBackgroundColor(resources.getColor(R.color.colorPrimary))
                    binding.purposeId.dating.setTextColor(resources.getColor(R.color.white))

                }
            })
        binding.purposeId.matrimony.setOnClickListener(
            View.OnClickListener {
                if (isMatrimony == true){
                    isMatrimony = false
//                    bin.mainId.purposeId.coffee.setBackgroundColor(R.color.colorPrimary)
                    binding.purposeId.matrimony.setBackgroundColor(resources.getColor(R.color.white))
                    binding.purposeId.matrimony.setTextColor(resources.getColor(R.color.colorPrimary))
                }else {
                    isCoffee = false
                    isBusiness = false
                    isHobbies = false
                    isFrienship = false
                    isMovies = false
                    isDinning = false
                    isDating = false
                    isMatrimony = true
                    binding.purposeId.matrimony.setBackgroundColor(resources.getColor(R.color.colorPrimary))
                    binding.purposeId.matrimony.setTextColor(resources.getColor(R.color.white))

                }
            })


    }
    private fun setAdapter() {
        /**********************************  gender name category  ***************************/
        MCons.availability_adapter = ArrayAdapter(requireContext(),R.layout.spinner_item_selected,resources.getStringArray(R.array.availability))
        MCons.availability_adapter.setDropDownViewResource(androidx.appcompat.R.layout.support_simple_spinner_dropdown_item)
        binding.availability.adapter = MCons.availability_adapter
        binding.availability.onItemSelectedListener =
            object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(
                    parent: AdapterView<*>,
                    view: View,
                    position: Int,
                    id: Long
                ) {
                    availableText =
                        if (parent.getItemAtPosition(position).toString().lowercase()
                                .contains("select", ignoreCase = true)
                        ) "" else parent.getItemAtPosition(position).toString()

                }

                override fun onNothingSelected(parent: AdapterView<*>?) {}
            }
    }


}