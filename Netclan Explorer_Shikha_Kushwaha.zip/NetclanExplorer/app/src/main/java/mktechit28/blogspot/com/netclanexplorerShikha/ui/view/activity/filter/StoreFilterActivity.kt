package mktechit28.blogspot.com.netclanexplorerShikha.ui.view.activity.filter

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import mktechit28.blogspot.com.netclanexplorerShikha.databinding.ActivityStoreFilterBinding

class StoreFilterActivity : AppCompatActivity() {
    lateinit var bin: ActivityStoreFilterBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        bin = ActivityStoreFilterBinding.inflate(layoutInflater)
        setContentView(bin.root)
    }
}