package com.example.netclanexplorer.ui.view.fragment

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.fragment.app.Fragment
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import mktechit28.blogspot.com.netclanexplorerShikha.R
import mktechit28.blogspot.com.netclanexplorerShikha.databinding.FragmentStoreBinding


class StoreFragment : Fragment() {
    lateinit var bin: FragmentStoreBinding
    val REQUEST_CODE: Int = 1
    var isSave: Boolean = false
    var isSaveAdd: Boolean = false
    val PERMISSION_REQUEST_COARSE_LOCATION: Int = 1


    private lateinit var mFusedLocationClient: FusedLocationProviderClient
    private val permissionId = 2

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        bin = FragmentStoreBinding.inflate(inflater, container, false)
        init()
        btnListener()
        return bin.root

    }

    private fun init() {
        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(requireActivity())
    }

    private fun btnListener() {
        bin.locationBtn.setOnClickListener {
//            onRequestPermissionsResult()
            setLocation()
        }
//        bin.filterBtn.setOnClickListener {
//            startActivity(Intent(requireContext(), StoreFilterActivity::class.java))
//        }
        bin.storeInviteBtn.setOnClickListener {
            bin.storeInviteBtn.text = "PENDING"
            bin.storeInviteBtn.isEnabled = false
            bin.storeInviteBtn.setTextColor(resources.getColor(R.color.text_color))
        }
        bin.contactImage.setOnClickListener {
            sendContactNo()
        }
        bin.contactSave.setOnClickListener {
//            isSaveAdd = true
            if (isSave) {
                isSave = true
                bin.contactSave.isEnabled = true
                bin.contactSave.setBackgroundColor(resources.getColor(R.color.colorPrimary))


            } else {
                isSave = false
                bin.contactSave.isEnabled = false
                bin.contactSave.setBackgroundColor(resources.getColor(R.color.text_color))
                Toast.makeText(requireContext(), "Added to Contacts", Toast.LENGTH_SHORT).show()
            }
//            saveContactNo()
        }
    }
//    private fun onRequestPermissionsResult(
//        requestCode: Int,
//        permissions: Array<String?>?,
//        grantResults: IntArray
//    ) {
//        when (requestCode) {
//            PERMISSION_REQUEST_COARSE_LOCATION -> {
//                if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
//                    Log.d(TAG, "coarse location permission granted")
//                } else {
//                    val intent = Intent()
//                    intent.action = android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS
//                    val uri = Uri.fromParts("package", getPackageName(), null)
//                    intent.data = uri
//                    startActivity(intent)
//                }
//            }
//        }
//    }

    private fun sendContactNo() {
        val callIntent = Intent(Intent.ACTION_DIAL)
        callIntent.data = Uri.parse("tel:0000000000")
        if (ActivityCompat.checkSelfPermission(
                requireContext(),
                Manifest.permission.CALL_PHONE
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(
                    requireActivity(),
                    Manifest.permission.CALL_PHONE
                )
            ) {
            } else {
                ActivityCompat.requestPermissions(
                    requireActivity(), arrayOf(Manifest.permission.CALL_PHONE),
                    REQUEST_CODE
                )
            }
        }
        startActivity(callIntent)


//        val callingIntent = Intent(ACTION_DIAL)
//        callingIntent.data = Uri.parse("tel: 1232456789")
//        startActivity(callingIntent)
    }

    private fun setLocation() {
        val uri =
            "http://maps.google.com/maps?saddr=" + "9982878" + "," + "76285774" + "&daddr=" + "9992084" + "," + "76286455"
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(uri))
        intent.setClassName("com.google.android.apps.maps", "com.google.android.maps.MapsActivity")
        startActivity(intent)
    }

}