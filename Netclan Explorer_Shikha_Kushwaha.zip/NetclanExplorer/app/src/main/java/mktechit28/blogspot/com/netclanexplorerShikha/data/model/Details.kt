package com.example.netclanexplorer.data.model

class Details {
    var name: String? = null
    var location: String? = null
    var data: String? = null
    var quotes: String? = null

    constructor(name: String?, location: String?, data: String?, quotes: String?) {
        this.name = name
        this.location = location
        this.data = data
        this.quotes = quotes
    }
}