package com.example.netclanexplorer.ui.view.activity

import android.Manifest
import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.location.Location
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.location.LocationManagerCompat
import androidx.core.view.GravityCompat
import androidx.fragment.app.Fragment
import androidx.viewpager.widget.ViewPager
import com.example.netclanexplorer.ui.adapter.ViewPagerAdapter
import com.example.netclanexplorer.ui.view.fragment.HomeFragment
import com.example.netclanexplorer.ui.view.fragment.StoreFragment
import com.example.netclanexplorer.ui.view.fragment.businessFragment
import com.example.netclanexplorer.ui.view.fragment.personFragment
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.tasks.OnSuccessListener
import com.karumi.dexter.Dexter
import com.karumi.dexter.MultiplePermissionsReport
import com.karumi.dexter.PermissionToken
import com.karumi.dexter.listener.PermissionRequest
import com.karumi.dexter.listener.multi.MultiplePermissionsListener
import mktechit28.blogspot.com.netclanexplorerShikha.R
import mktechit28.blogspot.com.netclanexplorerShikha.databinding.ActivityMainBinding


class MainActivity : AppCompatActivity() {
    lateinit var bin: ActivityMainBinding
    var isAllFabsVisible = false
    lateinit var locationManagerCompat: LocationManagerCompat
    private var locationEnabled = false
    private val fusedLocationClient: FusedLocationProviderClient? = null
    var currentLat = 0.0
    var currentLong:Double = 0.0
    var REQUEST_ID_MULTIPLE_PERMISSIONS: Int = 1


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        bin = ActivityMainBinding.inflate(layoutInflater)
        initView()
        btnlistner()
        checkPermissionLocation()
        checkPermissions()
        view_listner()
        checkAndRequestPermissions()
        setContentView(bin.root)
    }

//    Blurry.with(context).radius(25).sampling(2).onto(rootView)

    private fun view_listner() {
        isAllFabsVisible=false
        bin. sideActionBar.setOnClickListener(
            View.OnClickListener {
                isAllFabsVisible = if (!isAllFabsVisible) {
                    bin.sideActionBar.setImageResource(com.google.android.material.R.drawable.ic_m3_chip_close)
                    bin.lvfloatingcontainer.visibility=View.VISIBLE
                    bin.layourViewpager.setBackgroundDrawable( ColorDrawable(Color.TRANSPARENT))
                    bin.layourViewpager.setBackgroundDrawable(ContextCompat.getDrawable(this,R.drawable.card_bg) );
                    true
                } else {
                    bin.lvfloatingcontainer.visibility=View.GONE
                    bin.sideActionBar.setImageResource(R.drawable.ic_plus_icon)

                    false
                }
            })
    }


    fun checkAndRequestPermissions(): Boolean {
        val call = ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.CALL_PHONE)
        val listPermissionsNeeded = ArrayList<String>()
        if (call != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.CALL_PHONE)
        }

        if (!listPermissionsNeeded.isEmpty()) {
            ActivityCompat.requestPermissions(this@MainActivity, listPermissionsNeeded.toTypedArray(),
                REQUEST_ID_MULTIPLE_PERMISSIONS)
            return false
        }
        return true
    }
    private fun checkPermissions() {
        Dexter.withActivity(this).withPermissions(
            Manifest.permission.CAMERA,
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE,
            Manifest.permission.ACCESS_NOTIFICATION_POLICY
        )
            .withListener(object : MultiplePermissionsListener {
                override fun onPermissionsChecked(report: MultiplePermissionsReport) {
                    // good to go
                }

                override fun onPermissionRationaleShouldBeShown(
                    permissions: List<PermissionRequest>,
                    token: PermissionToken
                ) {
                    token.continuePermissionRequest()
                }
            }).check()
    }

    private fun checkPermissionLocation() {
        Dexter.withActivity(this).withPermissions(
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_BACKGROUND_LOCATION
        )
            .withListener(object : MultiplePermissionsListener {
                override fun onPermissionsChecked(report: MultiplePermissionsReport) {
                    if (report.areAllPermissionsGranted()) {
                        Log.i(
                            ContentValues.TAG,
                            "onPermissionsChecked: " + report.areAllPermissionsGranted()
                        )
                        locationEnabled = true

                        getCurrentlocation()
                    } else {
                        locationEnabled = false
//                        locationFetched()
                        Log.i(
                            ContentValues.TAG,
                            "onPermissionsChecked: some permission not granted"
                        )
                    }
                }

                override fun onPermissionRationaleShouldBeShown(
                    permissions: List<PermissionRequest?>?,
                    token: PermissionToken
                ) {
                    token.continuePermissionRequest()
                }
            }).check()
    }
    private fun getCurrentlocation() {
        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return
        }
        fusedLocationClient!!.getLastLocation()
            .addOnSuccessListener(this,
                OnSuccessListener<Location?> { location -> // Got last known location. In some rare situations this can be null.
                    if (location != null) {
                        currentLat = location.latitude
                        currentLong = location.longitude
                    }
                })
//        locationFetched()
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun btnlistner() {
        bin.dashboard.locationText
        bin.dashboard.drawerBtn.setOnClickListener {
            openDrawerCloseDrawer()
        }
    }

    fun loadFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction().replace(R.id.frame, fragment)
            .commit()
    }

    private fun openDrawerCloseDrawer() {
        if (!bin.drawerLayout.isDrawerOpen(GravityCompat.START)) {
            bin.drawerLayout.openDrawer(GravityCompat.START)
        }
    }

    private fun initView() {
//        bin.floatingBtn.addFab.visibility = View.VISIBLE
        bin.bottomAppBar.background = null
        bin.sideActionBar.visibility = View.GONE
        bin.lvfloatingcontainer.visibility = View.GONE
        loadFragment(HomeFragment(this))
        bin.bottomAppBar.setOnItemSelectedListener {
            when (it.itemId) {
                R.id.check -> {
                    loadFragment(HomeFragment(this))
                    bin.frame.visibility = View.VISIBLE
                    bin.layourViewpager.visibility = View.GONE
                    bin.sideActionBar.visibility = View.GONE
                }
                R.id.eye -> {
                    initViewPager()

                }
                R.id.network -> {
                }
                R.id.chat -> {
                }
                R.id.contact -> {
                }
            }
            true
        }
    }

    fun initViewPager() {
        bin.frame.visibility = View.GONE
        bin.layourViewpager.visibility = View.VISIBLE
        bin.tabLayout.setupWithViewPager(bin.viewPager)
        setupViewPager(bin.viewPager)
        bin.viewPager.adapter?.notifyDataSetChanged()
        setupTabIcons()
        bin.sideActionBar.visibility=View.VISIBLE
    }

    private fun setupViewPager(viewpager: ViewPager) {
        var adapter = ViewPagerAdapter(supportFragmentManager)
        adapter.addFragment(personFragment(), "")
        adapter.addFragment(businessFragment(), "")
        adapter.addFragment(StoreFragment(), "")
        viewpager.adapter = adapter
        adapter.notifyDataSetChanged()

    }

    private val tabIcons = intArrayOf(
        R.drawable.ic_baseline_diversity_3_24,
        R.drawable.ic_outline_business_center_24,
        R.drawable.ic_baseline_storefront_24
    )

    private fun setupTabIcons() {
        bin.tabLayout.getTabAt(0)?.setIcon(tabIcons[0])
        bin.tabLayout.getTabAt(1)?.setIcon(tabIcons[1])
        bin.tabLayout.getTabAt(2)?.setIcon(tabIcons[2])
    }
}
