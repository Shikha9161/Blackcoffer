package com.example.netclanexplorer.ui.view.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.netclanexplorer.data.model.Details
import com.example.netclanexplorer.ui.adapter.persondataAdapter
import mktechit28.blogspot.com.netclanexplorerShikha.databinding.FragmentPersonBinding


class personFragment : Fragment() {
    lateinit var binding: FragmentPersonBinding

    var dataList =  ArrayList<Details>()
    var adapter:  persondataAdapter? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding= FragmentPersonBinding.inflate(layoutInflater);
        initView()
        return binding.root
    }

    private fun initView() {

        dataList.add(Details("Shikha Kushwaha","Delhi, Within 100 m","Coffee | Friendship | Business","Hi community! Iam open to new \\nconneection"))
        dataList.add(Details("Shikha Kushwaha","Delhi, Within 100 m","Coffee | Friendship | Business","Hi community! Iam open to new \\nconneection"))
        dataList.add(Details("Shikha Kushwaha","Delhi, Within 100 m","Coffee | Friendship | Business","Hi community! Iam open to new \\nconneection"))
        dataList.add(Details("Shikha Kushwaha","Delhi, Within 100 m","Coffee | Friendship | Business","Hi community! Iam open to new \\nconneection"))
        dataList.add(Details("Shikha Kushwaha","Delhi, Within 100 m","Coffee | Friendship | Business","Hi community! Iam open to new \\nconneection"))

        adapter= persondataAdapter(requireContext(),dataList)
        binding.recyclerview.layoutManager = LinearLayoutManager(activity, RecyclerView.VERTICAL, false)
        binding.recyclerview.adapter=adapter
    }

}