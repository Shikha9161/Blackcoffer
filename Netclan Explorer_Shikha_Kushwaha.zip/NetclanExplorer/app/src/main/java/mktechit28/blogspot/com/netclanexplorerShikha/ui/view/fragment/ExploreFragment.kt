package com.example.netclanexplorer.ui.view.fragment

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import mktechit28.blogspot.com.netclanexplorerShikha.databinding.FragmentExploreBinding


class ExploreFragment : Fragment() {
    lateinit var binding: FragmentExploreBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding=FragmentExploreBinding.inflate(inflater,container,false)
        return binding.root
    }

}